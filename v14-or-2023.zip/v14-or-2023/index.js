const { Client, Partials, Collection, GatewayIntentBits, EmbedBuilder } = require("discord.js");
const db = require('pro.db');

// Files Handlers

const { loadEvents } = require("./Handlers/eventHandler");
const { loadCommands } = require("./Handlers/SlashCommand");

// intents, partials

const client = new Client({
  intents: [Object.keys(GatewayIntentBits)],
  partials: [Object.keys(Partials)],
});

// File Config

client.commands = new Collection();
client.config = require("./JSON/config.json");

// Ready

client.login(client.config.token).then(() => {
  loadEvents(client);
  loadCommands(client);
});

// express

const express = require('express')
const app = express()

app.get('/', function (req, res) {
  res.send('Hello World')
})

app.listen(3000)


// InvitesTracker

const InvitesTracker = require('@androz2091/discord-invites-tracker');

const tracker = InvitesTracker.init(client, {
    fetchGuilds: true,
    fetchVanity: true,
    fetchAuditLogs: true
});

const InvitesSchema = require("./Models/Inviter");

tracker.on('guildMemberAdd', (member, type, invite) => {

  InvitesSchema.findOne({Guild: member.guild.id}, async (err, data) => {
    if (!data) return;
    let channel = data.Channel;

  const InvitesChannel = member.guild.channels.cache.get(channel);

  if(type === 'normal'){
    InvitesChannel.send(`Hay ${member} just joined. They were invited by **${invite.inviter.username}**.`);
  }

  else if(type === 'vanity'){
    InvitesChannel.send(`Hay ${member} just joined. using a custom invite.`);
  }

  else if(type === 'unknown'){
    InvitesChannel.send(`Hay ${member} I can't figure out how you joined the server...`);
  }

  })

});

// InvitesTracker Embed

const InvitesEmbedSchema = require("./Models/Inviter-Embed");

tracker.on('guildMemberAdd', (member, type, invite) => {

InvitesEmbedSchema.findOne({Guild: member.guild.id}, async (err, data) => {
  if (!data) return;
  let channel = data.Channel;

const InvitesChannelEmbed = member.guild.channel.cache.get(channel)

  if(type === 'normal'){
    const normal = new EmbedBuilder()
      .setDescription(`Hay ${member} just joined. They were invited by **${invite.inviter.username}**.`)
      .setColor("DarkGrey");
    InvitesChannelEmbed.send({ embeds: [normal] })
  }

  else if(type === 'vanity'){
    const vanity = new EmbedBuilder()
      .setDescription(`Hay ${member} just joined. using a custom invite.`)
      .setColor("DarkGrey");
    InvitesChannelEmbed.send({ embeds: [vanity] })
  }

  else if(type === 'unknown'){
    const unknown = new EmbedBuilder()
      .setDescription(`Hay ${member} I can't figure out how you joined the server...`)
      .setColor("DarkGrey");
    InvitesChannelEmbed.send({ embeds: [unknown] })
  }

  })
});

// Giveaway

const { GiveawaysManager } = require('discord-giveaways');
const manager = new GiveawaysManager(client, {
    storage: './JSON/giveaways.json',
    default: {
        botsCanWin: false,
        embedColor: 0x0FFF00,
        embedColorEnd: 0xFF0004,
        reaction: '🎉'
    }
});

client.giveawaysManager = manager;

// Error Command

process.on("unhandledRejection", (reason, p) => {
  const ChannelID = "1062727157765394513";
  console.error("Unhandled promise rejection:", reason, p);
  const Embed = new EmbedBuilder()
    .setColor("Random")
    .setTimestamp()
    .setFooter({ text: "⚠️Anti Crash system" })
    .setTitle("Error Encountered");
  const Channel = client.channels.cache.get(ChannelID);
  if (!Channel) return;
  Channel.send({
    embeds: [
      Embed.setDescription(
        "**Unhandled Rejection/Catch:\n\n** ```" + reason + "```"
      ),
    ],
  });
});

// TileOut

setTimeout(() => {
  if (!client || !client.user) {
    console.log("Client Not Login, Process Kill")
    process.kill(1);
  } else {
    console.log("Client Login")
  }
}, 3*1000*60); 

// Distube

const { DisTube } = require('distube');
const { SpotifyPlugin } = require('@distube/spotify');

// Distube LogIn

client.distube = new DisTube(client, {
  emitNewSongOnly: true,
  leaveOnFinish: true,
  emitAddSongWhenCreatingQueue: false,
  plugins: [new SpotifyPlugin]
})

// AutoReply

client.on('messageCreate', (message) => {

const AutoReply = require("./Models/AutoReply");

AutoReply.findOne({Guild: message.guild.id}, async (err, data) => {
    if (!data) return;
    let content = data.content;
    let Reply = data.reply;

    if (message.content === content ) {
        message.reply(Reply)
    }

  })
})

// client

module.exports = client;