const {model, Schema} = require('mongoose');

let welcomeMsgSchema = new Schema({
    Guild: String,
    Channel: String,
    Role: String
});

module.exports = model("WelcomeMsg", welcomeMsgSchema);