const {model, Schema} = require('mongoose');

let InvitesSchema = new Schema({
    Guild: String,
    Channel: String,
});

module.exports = model("Inviter", InvitesSchema);