const {model, Schema} = require('mongoose');

let InvitesEmbedSchema = new Schema({
    Guild: String,
    Channel: String,
});

module.exports = model("InviterEmbed", InvitesEmbedSchema);