const { model, Schema } = require("mongoose");

let EconomySchema = new Schema({
    Guildid: String,
    User: String,
    credits: Number
});

module.exports = model("Economy", EconomySchema)