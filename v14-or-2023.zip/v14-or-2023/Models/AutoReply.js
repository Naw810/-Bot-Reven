const {model, Schema} = require('mongoose');

let AutoReplySchema = new Schema({
    Guild: String,
    content: String,
    reply: String
});

module.exports = model("AutoReply", AutoReplySchema);