const { EmbedBuilder } = require('discord.js');
const config = require("../../JSON/config.json");
const mongoose = require('mongoose');

module.exports = {
    name: "ready",
    once: true,
    async execute(client) {

      await mongoose.connect(config.mongodb || '', {
            keepAlive: true,
        });

        if (mongoose.connect) {
            console.log('MongoDB connection succesful.')
        }

        console.log(`${client.user.username} is now Ready.`);
    }, 
};