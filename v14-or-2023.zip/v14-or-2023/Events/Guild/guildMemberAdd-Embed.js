const { EmbedBuilder } = require("@discordjs/builders");
const Schema = require("../../Models/Welcome")

module.exports = {
    name: "guildMemberAdd",
    async execute(member) {

        Schema.findOne({Guild: member.guild.id}, async (err, data) => {
            if (!data) return;
            let channel = data.Channel;
            let Role = data.Role;

            const {guild} = member;
            const welcomeChannels = member.guild.channels.cache.get(channel);
            const JoinDiscord = `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`

            const welcomeEmbede = new EmbedBuilder()
                .setAuthor({ name: `${member.guild.name}`, iconURL: member.guild.iconURL({ dynamic: true, size: 1024, format: 'png' }) })
                .setThumbnail(`${member.user.displayAvatarURL({ dynamic: true, size: 1024, format: 'png' })}`)
                .setDescription(`
                    ⦉⬢⬢⚌⚌⚌ ⋐🆆🅴🅛🅲🅞🅼🅴⋑ ⚌⚌⚌⬢⬢⦊

                    🌹👋 Welcome To **${member.guild.name}** 👋🌹

                    > 🧑 ╔ ┋ username : ${member.user.tag}

                    > 📢 ╣ ┋ Mention : ${member.user}

                    > 📊 ╣ ┋ Members Server : ${member.guild.memberCount}

                    > 🌐 ╚ ┋ Joined Discord : ${JoinDiscord}

                    ⦉⬢⬢⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⬢⬢⦊
                    `)
                    .setColor(0x006c7f)
                    .setTimestamp();
            
            welcomeChannels.send({ embeds: [welcomeEmbede] })
            member.roles.add(Role);
        })
    }
}