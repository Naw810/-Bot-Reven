const { EmbedBuilder } = require("@discordjs/builders");
const Schema = require("../../Models/WelcomeMsg")

module.exports = {
    name: "guildMemberAdd",
    async execute(member) {

        Schema.findOne({Guild: member.guild.id}, async (err, data) => {
            if (!data) return;
            let channel = data.Channel;
            let Role = data.Role;

            const {guild} = member;
            const welcomeChannels = member.guild.channels.cache.get(channel);
            
            welcomeChannels.send({ content: `
𝗪𝗲𝗹𝗰𝗼𝗺𝗲 𝗧𝗼 **${guild.name}**

𝐌𝐞𝐦𝐛𝐞𝐫 ${member}

𝐌𝐞𝐦𝐛𝐞𝐫 𝐍𝐮𝐦𝐛𝐞 **${member.guild.memberCount}**
` })
            member.roles.add(Role);
        })
    }
}