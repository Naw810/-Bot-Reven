const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { COOLDOWN } = require('../../JSON/config.json');
module.exports = {
  cooldown: COOLDOWN,
    data: new SlashCommandBuilder()
        .setName("timeout")
        .setDescription("Get A Timeout To A Member.")
        .addUserOption(option =>
            option.setName("target")
                .setDescription("User to be Timeout.")
                .setRequired(true)
        ),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("You don't have `BanMembers` permission.")
            ], ephemeral: true
        });

        const { channel, options } = interaction;

        const roles = interaction.options.getRole('role');
        const member = interaction.options.getMember('target');

        const errEmbed = new EmbedBuilder()
            .setDescription(`I could not assign timeout to a member ${member}.`)
            .setColor(0xc72c3b);

        if (member.roles.highest.position >= interaction.member.roles.highest.position)
            return interaction.reply({ embeds: [errEmbed], ephemeral: true });

        await member.timeout(60_000);

        const embed = new EmbedBuilder()
            .setDescription(`> 💨 The User Has Been Given Member ${member} Timeout ✨`)
            .setColor(0x5fb041)
            .setTimestamp()

        await interaction.reply({
            embeds: [embed]
        });
    }
}