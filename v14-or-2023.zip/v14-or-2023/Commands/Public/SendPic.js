const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { PermissionFlagsBits } = require('discord.js');
const { COOLDOWN } = require('../../JSON/config.json');
module.exports = {
  cooldown: COOLDOWN,
  data: new SlashCommandBuilder()
    .setName("send-pic")
    .setDescription("send images in channel")
    .addAttachmentOption((option)=> option.setRequired(true).setName("image0").setDescription("Choose the image you want"))
    .addAttachmentOption((option)=> option.setName("image1").setDescription("Choose the image you want")),
    async execute(interaction, client){
         // Permission
         if (!interaction.member.permissions.has(PermissionFlagsBits.AttachFiles)) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("You don't have `AttachFiles` permission.")
            ], ephemeral: true
        });
        try {
            function embedMessage(n){ return new EmbedBuilder() .setImage(n) .setColor(0x8302fa) .setTimestamp() .setFooter({ text: `by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({dynamic: true})}) };
            const image0 = interaction.options.getAttachment('image0');
            const image1 = interaction.options.getAttachment('image1');
            if(image0){
                await interaction.channel.send({ embeds:[embedMessage(image0.url)] })
                await interaction.channel.send({ content:line })
            }
            
            if(image1){
                await interaction.channel.send({ embeds:[embedMessage(image1.url)] })
                await interaction.channel.send({ content:line })
            }
        } catch (error) {
            await interaction.reply({ content:"The picture has been sent", ephemeral:true })
        }
    },
};