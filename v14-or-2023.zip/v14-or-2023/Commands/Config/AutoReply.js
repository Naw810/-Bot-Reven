const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require("discord.js");
const AutoReply = require("../../Models/AutoReply");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("auto-reply")
        .setDescription("Code to create an auto reply.")
        .addStringOption(option =>
            option.setName("content")
                .setDescription("The message that will be sent by the member.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName("reply")
                .setDescription("The response that the bot will send back is automatic.")
                .setRequired(true)
        ),

    async execute(interaction) {

        if (!interaction.member.permissions.has(PermissionFlagsBits.SendMessages)) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("You don't have `SendMessages` permission.")
            ], ephemeral: true
        });
        
        const { channel, options } = interaction;

        const Content = options.getString("content");
        const Reply = options.getString("reply");

        const embed = new EmbedBuilder();

        AutoReply.findOne({ Guild: interaction.guild.id }, async (err, data) => {
            if (!data) {
                await AutoReply.create({
                    Guild: interaction.guild.id,
                    content: Content,
                    reply: Reply
                });

                embed.setDescription("Data was succesfully sent to the database.")
                    .setColor("Green")
                    .setTimestamp();
            } else if (data) {
                AutoReply.findOneAndDelete({ Guild: interaction.guild.id });
                await AutoReply.create({
                    Guild: interaction.guild.id,
                    content: Content,
                    reply: Reply
                });

                embed.setDescription("Old data was succesfully replaced with the new data.")
                    .setColor("Green")
                    .setTimestamp();
            }

            if (err) {
                console.log(err);
                const EmbedError = new EmbedBuilder()
                    .setTitle("Error")
                    .setDescription("Something went wrong. Please contact the developers")
                    .setColor("Red")
                    .setTimestamp()
    
                await interaction.reply({ embeds: [EmbedError], ephemeral: true });
            }

            return interaction.reply({ embeds: [embed], ephemeral: true });
        })
    }
}