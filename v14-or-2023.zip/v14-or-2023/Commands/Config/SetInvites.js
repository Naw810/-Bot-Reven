const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require("discord.js");
const SetInvite = require("../../Models/Inviter");
const { COOLDOWN } = require('../../JSON/config.json');

module.exports = {
  cooldown: COOLDOWN,
    data: new SlashCommandBuilder()
        .setName("setinvites")
        .setDescription("Set up your Invite channel.")
        .addChannelOption(option =>
            option.setName("channel")
                .setDescription("Channel for Invite messages.")
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
        ),

    async execute(interaction) {
        //permissions
        if (!interaction.member.permissions.has(PermissionFlagsBits.SendMessages)) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("You don't have `SendMessages` permission.")
            ], ephemeral: true
        });
        
        const { channel, guildId, options } = interaction;
        const invitesChannel = options.getChannel("channel") || channel;
        const embed = new EmbedBuilder();

        SetInvite.findOne({ Guild: guildId }, async (err, data) => {
            if (!data) {
                await SetInvite.create({
                    Guild: guildId,
                    Channel: invitesChannel.id
                });

                embed.setDescription("Data was succesfully sent to the database.")
                    .setColor("Green")
                    .setTimestamp();
            } else if (data) {
                SetInvite.findOneAndDelete({ Guild: guildId });
                await SetInvite.create({
                    Guild: guildId,
                    Channel: invitesChannel.id
                });

                embed.setDescription("Old data was succesfully replaced with the new data.")
                    .setColor("Green")
                    .setTimestamp();
            }

            if (err) {
                console.log(err);
                const EmbedError = new EmbedBuilder()
                    .setTitle("Error")
                    .setDescription("Something went wrong. Please contact the developers")
                    .setColor("Red")
                    .setTimestamp()
    
                await interaction.reply({ embeds: [EmbedError], ephemeral: true });
            }

            return interaction.reply({ embeds: [embed], ephemeral: true });
        })
    }
}