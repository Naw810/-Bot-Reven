const {SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType} = require("discord.js");
const welcomeSchema = require("../../Models/Welcome");
const { COOLDOWN } = require('../../JSON/config.json');

module.exports = {
  cooldown: COOLDOWN,
    data: new SlashCommandBuilder()
    .setName("setwelcome-embed")
    .setDescription("Set Up Your Welcome Message +\n PS.")
    .addChannelOption(option => 
        option.setName("channel")
        .setDescription("Channel For Welcome Messages.")
        .setRequired(true)
        .addChannelTypes(ChannelType.GuildText)
    )
    .addRoleOption(option =>
        option.setName("welcome-role")
        .setDescription("Enter your welcome role.")
        .setRequired(true)    
    ),

    async execute(interaction) {
        //permissions
        if (!interaction.member.permissions.has(PermissionFlagsBits.SendMessages)) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription("You don't have `SendMessages` permission.")
            ], ephemeral: true
        });
        const {channel, options} = interaction;
        const welcomeChannel = options.getChannel("channel");
        const roleId = options.getRole("welcome-role");

        if(!interaction.guild.members.me.permissions.has(PermissionFlagsBits.SendMessages)) {
            interaction.reply({content: "I don't have permissions for this.", ephemeral: true});
        }

        welcomeSchema.findOne({Guild: interaction.guild.id}, async (err, data) => {
            if(!data) {
                const newWelcome = await welcomeSchema.create({
                    Guild: interaction.guild.id,
                    Channel: welcomeChannel.id,
                    Role: roleId.id,
                });
            }
            interaction.reply({content: 'Succesfully created a welcome message', ephemeral: true});
        })
    }
}